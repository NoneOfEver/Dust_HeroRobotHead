//
// Created by 宋元 on 2025/11/2.
///**
//@file bsp_can.cpp
// @author Libaoen
// @brief
// @version 1.0
// @date 2025-11-02
#include "bsp_can.h"

CanManageObject g_can1_manage_object = {0};
CanManageObject g_can2_manage_object = {0};

// CAN通信发送缓冲区
uint8_t g_can1_0x1ff_tx_data[8];
uint8_t g_can1_0x200_tx_data[8];
uint8_t g_can1_0x2ff_tx_data[8];
uint8_t g_can1_0x3fe_tx_data[8];
uint8_t g_can1_0x4fe_tx_data[8];

uint8_t g_can2_0x1ff_tx_data[8];
uint8_t g_can2_0x200_tx_data[8];
uint8_t g_can2_0x2ff_tx_data[8];
uint8_t g_can2_0x3fe_tx_data[8];
uint8_t g_can2_0x4fe_tx_data[8];

uint8_t g_can_supercap_tx_data[8];

/**
 * @brief 初始化CAN总线
 *
 * @param hcan CAN编号
 * @param callback_function 处理回调函数
 */
void can_init(CAN_HandleTypeDef *hcan, CanCallback callback_function)
{
    if (hcan->Instance == CAN1)
    {
        g_can1_manage_object.can_handler = hcan;
        g_can1_manage_object.callback_function = callback_function;
        can_filter_mask_config(hcan, CAN_FILTER(0) | CAN_FIFO_0 | CAN_STDID | CAN_DATA_TYPE, 0, 0);
        can_filter_mask_config(hcan, CAN_FILTER(1) | CAN_FIFO_1 | CAN_STDID | CAN_DATA_TYPE, 0, 0);
    }
    else if (hcan->Instance == CAN2)
    {
        g_can2_manage_object.can_handler = hcan;
        g_can2_manage_object.callback_function = callback_function;
        can_filter_mask_config(hcan, CAN_FILTER(14) | CAN_FIFO_0 | CAN_STDID | CAN_DATA_TYPE, 0, 0);
        can_filter_mask_config(hcan, CAN_FILTER(15) | CAN_FIFO_1 | CAN_STDID | CAN_DATA_TYPE, 0, 0);
    }

    if(HAL_CAN_Start(hcan) != HAL_OK)
    {
        Error_Handler();
    }

    // 激活FIFO0和FIFO1消息挂起中断
    if(HAL_CAN_ActivateNotification(hcan, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK)
    {
        Error_Handler();
    }
    if(HAL_CAN_ActivateNotification(hcan, CAN_IT_RX_FIFO1_MSG_PENDING) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
 * @brief 配置CAN的过滤器
 *
 * @param hcan CAN编号
 * @param object_para 编号 | FIFOx | ID类型 | 帧类型
 * @param id ID
 * @param Mask_ID 屏蔽位(0x3ff, 0x1fffffff)
 */
void can_filter_mask_config(CAN_HandleTypeDef *hcan, uint8_t object_para, uint32_t id, uint32_t mask_id)
{
    CAN_FilterTypeDef filter = {0};

    assert_param(hcan != NULL);

    // 解析参数
    uint8_t filter_index = object_para >> 3;
    uint8_t fifo_select  = (object_para >> 2) & 0x01;
    uint8_t id_type_flag = (object_para >> 1) & 0x01;
    uint8_t frame_type   = object_para & 0x01;

    filter.FilterBank = filter_index;
    filter.FilterFIFOAssignment = fifo_select; // 0->FIFO0, 1->FIFO1
    filter.FilterActivation = ENABLE;
    filter.FilterMode = CAN_FILTERMODE_IDMASK;
    filter.FilterScale = CAN_FILTERSCALE_32BIT; // 使用32位滤波器

    if(id_type_flag == 0) // 标准ID
    {
        // 标准ID 11bit，左移5位到FilterIdHigh寄存器
        filter.FilterIdHigh = (id << 5) & 0xFFFF;
        filter.FilterIdLow = 0;
        filter.FilterMaskIdHigh = (mask_id << 5) & 0xFFFF;
        filter.FilterMaskIdLow = 0;
    }
    else // 扩展ID
    {
        // 扩展ID 29bit，需拆分成高低寄存器，且设置IDE位
        filter.FilterIdHigh = (uint16_t)((id >> 13) & 0xFFFF);
        filter.FilterIdHigh |= (1 << 2); // IDE位，扩展帧标志
        filter.FilterIdLow = (uint16_t)((id << 3) & 0xFFFF);

        filter.FilterMaskIdHigh = (uint16_t)((mask_id >> 13) & 0xFFFF);
        filter.FilterMaskIdHigh |= (1 << 2);
        filter.FilterMaskIdLow = (uint16_t)((mask_id << 3) & 0xFFFF);
    }

    UNUSED(frame_type); // 经典CAN滤波器不区分数据帧/远程帧滤波

    HAL_CAN_ConfigFilter(hcan, &filter);
}

/**
 * @brief 发送数据帧
 *
 * @param hcan CAN编号
 * @param ID ID
 * @param Data 被发送的数据指针
 * @param Length 长度
 * @return uint8_t 执行状态
 */
uint8_t can_send_data(CAN_HandleTypeDef *hcan, uint16_t id, uint8_t *data, uint16_t length)
{
    CAN_TxHeaderTypeDef tx_header;
    uint32_t tx_mailbox;

    assert_param(hcan != NULL);
    assert_param(length <= 8); // 经典CAN数据最大8字节

    tx_header.StdId = id;                     // 标准ID
    tx_header.ExtId = 0;                      // 不用扩展ID
    tx_header.IDE = CAN_ID_STD;               // 标准帧
    tx_header.RTR = CAN_RTR_DATA;             // 数据帧
    tx_header.DLC = length;                    // 数据长度
    tx_header.TransmitGlobalTime = DISABLE;   // 不发送时间戳

    if (HAL_CAN_AddTxMessage(hcan, &tx_header, data, &tx_mailbox) != HAL_OK)
    {
        // 发送失败
        return 1;
    }

    // 发送成功
    return 0;
}
void can_period_elapsed_callback()
{
    // DJI电机专属
    // CAN1电机

}
/**
 * @brief HAL库CAN接收FIFO0中断
 *
 * @param hcan CAN编号
 */
/**
 * @brief HAL库CAN接收FIFO0中断回调
 *
 * @param hcan CAN句柄指针
 */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    CAN_RxHeaderTypeDef rx_header;
    uint8_t rx_data[8];

    if (hcan->Instance == CAN1)
    {
        if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data) == HAL_OK)
        {
            // 拷贝数据到管理对象缓冲区
            g_can1_manage_object.rx_buffer.header = rx_header;
            memcpy(g_can1_manage_object.rx_buffer.data, rx_data, 8);

            // 调用回调处理函数
            if (g_can1_manage_object.callback_function)
                g_can1_manage_object.callback_function(&g_can1_manage_object.rx_buffer);
        }
    }
    else if (hcan->Instance == CAN2)
    {
        if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data) == HAL_OK)
        {
            g_can2_manage_object.rx_buffer.header = rx_header;
            memcpy(g_can2_manage_object.rx_buffer.data, rx_data, 8);

            if (g_can2_manage_object.callback_function)
                g_can2_manage_object.callback_function(&g_can2_manage_object.rx_buffer);
        }
    }
    // 如果有CAN3的话，STM32F4没有硬件支持CAN3，需要忽略或者自己扩展
}

/**
 * @brief HAL库CAN接收FIFO1中断
 *
 * @param hcan CAN编号
 */
void HAL_CAN_RxFifo1MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    CAN_RxHeaderTypeDef rx_header;
    uint8_t rx_data[8];

    if (hcan->Instance == CAN1)
    {
        if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data) == HAL_OK)
        {
            // 拷贝数据到管理对象缓冲区
            g_can1_manage_object.rx_buffer.header = rx_header;
            memcpy(g_can1_manage_object.rx_buffer.data, rx_data, 8);

            // 调用回调处理函数
            if (g_can1_manage_object.callback_function)
                g_can1_manage_object.callback_function(&g_can1_manage_object.rx_buffer);
        }
    }
    else if (hcan->Instance == CAN2)
    {
        if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data) == HAL_OK)
        {
            g_can2_manage_object.rx_buffer.header = rx_header;
            memcpy(g_can2_manage_object.rx_buffer.data, rx_data, 8);

            if (g_can2_manage_object.callback_function)
                g_can2_manage_object.callback_function(&g_can2_manage_object.rx_buffer);
        }
    }
}
