//
// Created by noe on 25-8-15.
//

#ifndef INIT_H
#define INIT_H

#ifdef __cplusplus
extern "C" {
#endif

void Init();

#ifdef __cplusplus
};
#endif

#endif //INIT_H